---
name: "Documentation"
about: "Found a typo or something that needs clarification?"
---

<!-- Thanks for taking the time to open an issue and help make the docs better -->

## Motivation

<!-- Why should we update our docs? -->

<!-- What should we do instead? -->

## Suggestion

<!-- What should we do instead? -->